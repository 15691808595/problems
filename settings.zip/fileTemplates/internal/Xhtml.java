/* * 通过WebStorm创建 * 用户:${USER} * 日期:${DATE} * 时间:${TIME} */package ${PACKAGE_NAME};
public xhtml ${NAME} { }